-- INVENTRACK VMS Commit 002 — PostgreSQL initial inventory foundation
-- Apply only if you are not applying the EF Core migration to the same database.
BEGIN;

CREATE TABLE IF NOT EXISTS tenants (
    "Id" uuid PRIMARY KEY,
    "Code" varchar(40) NOT NULL UNIQUE,
    "Name" varchar(200) NOT NULL,
    "IsActive" boolean NOT NULL DEFAULT true,
    "CreatedAtUtc" timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS sites (
    "Id" uuid PRIMARY KEY, "TenantId" uuid NOT NULL REFERENCES tenants("Id"),
    "CreatedAtUtc" timestamptz NOT NULL DEFAULT now(), "UpdatedAtUtc" timestamptz NOT NULL DEFAULT now(),
    "CreatedBy" varchar(120), "UpdatedBy" varchar(120), "RowVersion" bytea NOT NULL DEFAULT decode('','hex'),
    "Code" varchar(80) NOT NULL, "Name" varchar(200) NOT NULL, "TimeZoneId" varchar(100), "IsActive" boolean NOT NULL DEFAULT true,
    UNIQUE ("TenantId","Code")
);
CREATE TABLE IF NOT EXISTS items (
    "Id" uuid PRIMARY KEY, "TenantId" uuid NOT NULL REFERENCES tenants("Id"),
    "CreatedAtUtc" timestamptz NOT NULL DEFAULT now(), "UpdatedAtUtc" timestamptz NOT NULL DEFAULT now(),
    "CreatedBy" varchar(120), "UpdatedBy" varchar(120), "RowVersion" bytea NOT NULL DEFAULT decode('','hex'),
    "Code" varchar(80) NOT NULL, "Description" varchar(500) NOT NULL, "Category" varchar(40) NOT NULL,
    "BaseUom" varchar(12) NOT NULL, "MaterialGrade" varchar(120), "IsTraceabilityRequired" boolean NOT NULL DEFAULT true,
    "IsShelfLifeControlled" boolean NOT NULL DEFAULT false, "ShelfLifeDays" integer, "IsActive" boolean NOT NULL DEFAULT true,
    UNIQUE ("TenantId","Code"), CHECK ("ShelfLifeDays" IS NULL OR "ShelfLifeDays" > 0)
);
CREATE TABLE IF NOT EXISTS warehouses (
    "Id" uuid PRIMARY KEY, "TenantId" uuid NOT NULL REFERENCES tenants("Id"),
    "CreatedAtUtc" timestamptz NOT NULL DEFAULT now(), "UpdatedAtUtc" timestamptz NOT NULL DEFAULT now(),
    "CreatedBy" varchar(120), "UpdatedBy" varchar(120), "RowVersion" bytea NOT NULL DEFAULT decode('','hex'),
    "SiteId" uuid NOT NULL REFERENCES sites("Id"), "Code" varchar(80) NOT NULL, "Name" varchar(200) NOT NULL, "IsActive" boolean NOT NULL DEFAULT true,
    UNIQUE ("TenantId","SiteId","Code")
);
CREATE TABLE IF NOT EXISTS bin_locations (
    "Id" uuid PRIMARY KEY, "TenantId" uuid NOT NULL REFERENCES tenants("Id"),
    "CreatedAtUtc" timestamptz NOT NULL DEFAULT now(), "UpdatedAtUtc" timestamptz NOT NULL DEFAULT now(),
    "CreatedBy" varchar(120), "UpdatedBy" varchar(120), "RowVersion" bytea NOT NULL DEFAULT decode('','hex'),
    "WarehouseId" uuid NOT NULL REFERENCES warehouses("Id"), "Code" varchar(100) NOT NULL, "ZoneCode" varchar(30) NOT NULL,
    "Aisle" varchar(30), "Rack" varchar(30), "Level" varchar(30), "Bin" varchar(30), "CapacityQuantity" numeric(18,4),
    "IsQuarantine" boolean NOT NULL DEFAULT false, "IsActive" boolean NOT NULL DEFAULT true,
    UNIQUE ("TenantId","WarehouseId","Code")
);
CREATE TABLE IF NOT EXISTS inventory_lots (
    "Id" uuid PRIMARY KEY, "TenantId" uuid NOT NULL REFERENCES tenants("Id"),
    "CreatedAtUtc" timestamptz NOT NULL DEFAULT now(), "UpdatedAtUtc" timestamptz NOT NULL DEFAULT now(),
    "CreatedBy" varchar(120), "UpdatedBy" varchar(120), "RowVersion" bytea NOT NULL DEFAULT decode('','hex'),
    "ItemId" uuid NOT NULL REFERENCES items("Id"), "LotNumber" varchar(120) NOT NULL, "HeatNumber" varchar(120),
    "SupplierLotNumber" varchar(120), "ManufactureDate" date, "CureDate" date, "ExpiryDate" date,
    "CountryOfOrigin" varchar(2), "MaterialTestCertificateNumber" varchar(120), "QualityStatus" varchar(40) NOT NULL,
    UNIQUE ("TenantId","ItemId","LotNumber")
);
CREATE TABLE IF NOT EXISTS inventory_balances (
    "Id" uuid PRIMARY KEY, "TenantId" uuid NOT NULL REFERENCES tenants("Id"),
    "CreatedAtUtc" timestamptz NOT NULL DEFAULT now(), "UpdatedAtUtc" timestamptz NOT NULL DEFAULT now(),
    "CreatedBy" varchar(120), "UpdatedBy" varchar(120), "RowVersion" bytea NOT NULL DEFAULT decode('','hex'),
    "ItemId" uuid NOT NULL REFERENCES items("Id"), "WarehouseId" uuid NOT NULL REFERENCES warehouses("Id"),
    "BinLocationId" uuid NOT NULL REFERENCES bin_locations("Id"), "InventoryLotId" uuid REFERENCES inventory_lots("Id"),
    "Status" integer NOT NULL, "QuantityOnHand" numeric(18,4) NOT NULL, "QuantityAllocated" numeric(18,4) NOT NULL,
    "BaseUom" varchar(12) NOT NULL, CHECK ("QuantityOnHand" >= 0 AND "QuantityAllocated" >= 0 AND "QuantityAllocated" <= "QuantityOnHand"),
    UNIQUE ("TenantId","ItemId","WarehouseId","BinLocationId","InventoryLotId","Status")
);
CREATE TABLE IF NOT EXISTS inventory_transactions (
    "Id" uuid PRIMARY KEY, "TenantId" uuid NOT NULL REFERENCES tenants("Id"),
    "CreatedAtUtc" timestamptz NOT NULL DEFAULT now(), "UpdatedAtUtc" timestamptz NOT NULL DEFAULT now(),
    "CreatedBy" varchar(120), "UpdatedBy" varchar(120), "RowVersion" bytea NOT NULL DEFAULT decode('','hex'),
    "TransactionNumber" varchar(80) NOT NULL, "TransactionType" varchar(60) NOT NULL, "ItemId" uuid NOT NULL REFERENCES items("Id"),
    "InventoryLotId" uuid REFERENCES inventory_lots("Id"), "FromWarehouseId" uuid REFERENCES warehouses("Id"),
    "FromBinLocationId" uuid REFERENCES bin_locations("Id"), "ToWarehouseId" uuid REFERENCES warehouses("Id"),
    "ToBinLocationId" uuid REFERENCES bin_locations("Id"), "Quantity" numeric(18,4) NOT NULL, "BaseUom" varchar(12) NOT NULL,
    "ReferenceType" varchar(80) NOT NULL, "ReferenceNumber" varchar(120), "PostedAtUtc" timestamptz NOT NULL,
    "PostedBy" varchar(120) NOT NULL, "ReasonCode" varchar(80), UNIQUE ("TenantId","TransactionNumber")
);
CREATE INDEX IF NOT EXISTS ix_inventory_transactions_tenant_item_posted ON inventory_transactions("TenantId","ItemId","PostedAtUtc");

CREATE TABLE IF NOT EXISTS suppliers (
    "Id" uuid PRIMARY KEY, "TenantId" uuid NOT NULL REFERENCES tenants("Id"),
    "CreatedAtUtc" timestamptz NOT NULL DEFAULT now(), "UpdatedAtUtc" timestamptz NOT NULL DEFAULT now(),
    "CreatedBy" varchar(120), "UpdatedBy" varchar(120), "RowVersion" bytea NOT NULL DEFAULT decode('','hex'),
    "Code" varchar(80) NOT NULL, "Name" varchar(250) NOT NULL, "TaxRegistrationNumber" varchar(100),
    "CountryCode" varchar(2), "Email" varchar(250), "Phone" varchar(40), "IsApproved" boolean NOT NULL DEFAULT false,
    "IsActive" boolean NOT NULL DEFAULT true, UNIQUE ("TenantId","Code")
);
CREATE TABLE IF NOT EXISTS purchase_orders (
    "Id" uuid PRIMARY KEY, "TenantId" uuid NOT NULL REFERENCES tenants("Id"),
    "CreatedAtUtc" timestamptz NOT NULL DEFAULT now(), "UpdatedAtUtc" timestamptz NOT NULL DEFAULT now(),
    "CreatedBy" varchar(120), "UpdatedBy" varchar(120), "RowVersion" bytea NOT NULL DEFAULT decode('','hex'),
    "OrderNumber" varchar(80) NOT NULL, "SupplierId" uuid NOT NULL REFERENCES suppliers("Id"), "SiteId" uuid NOT NULL REFERENCES sites("Id"),
    "OrderDate" date NOT NULL, "ExpectedDate" date, "CurrencyCode" varchar(3) NOT NULL, "Status" varchar(40) NOT NULL,
    "TotalAmount" numeric(18,2) NOT NULL, UNIQUE ("TenantId","OrderNumber")
);
CREATE TABLE IF NOT EXISTS purchase_order_lines (
    "Id" uuid PRIMARY KEY, "TenantId" uuid NOT NULL REFERENCES tenants("Id"),
    "CreatedAtUtc" timestamptz NOT NULL DEFAULT now(), "UpdatedAtUtc" timestamptz NOT NULL DEFAULT now(),
    "CreatedBy" varchar(120), "UpdatedBy" varchar(120), "RowVersion" bytea NOT NULL DEFAULT decode('','hex'),
    "PurchaseOrderId" uuid NOT NULL REFERENCES purchase_orders("Id"), "LineNumber" integer NOT NULL, "ItemId" uuid NOT NULL REFERENCES items("Id"),
    "OrderedQuantity" numeric(18,4) NOT NULL, "ReceivedQuantity" numeric(18,4) NOT NULL, "UnitPrice" numeric(18,2) NOT NULL,
    "BaseUom" varchar(12) NOT NULL, "RequiredDate" date, "ProjectCode" varchar(80), UNIQUE ("TenantId","PurchaseOrderId","LineNumber")
);
CREATE TABLE IF NOT EXISTS goods_receipts (
    "Id" uuid PRIMARY KEY, "TenantId" uuid NOT NULL REFERENCES tenants("Id"),
    "CreatedAtUtc" timestamptz NOT NULL DEFAULT now(), "UpdatedAtUtc" timestamptz NOT NULL DEFAULT now(),
    "CreatedBy" varchar(120), "UpdatedBy" varchar(120), "RowVersion" bytea NOT NULL DEFAULT decode('','hex'),
    "ReceiptNumber" varchar(80) NOT NULL, "SupplierId" uuid NOT NULL REFERENCES suppliers("Id"), "PurchaseOrderId" uuid REFERENCES purchase_orders("Id"),
    "WarehouseId" uuid NOT NULL REFERENCES warehouses("Id"), "ReceivedAtUtc" timestamptz NOT NULL,
    "SupplierDeliveryNote" varchar(120) NOT NULL, "Status" varchar(40) NOT NULL, UNIQUE ("TenantId","ReceiptNumber")
);
CREATE TABLE IF NOT EXISTS goods_receipt_lines (
    "Id" uuid PRIMARY KEY, "TenantId" uuid NOT NULL REFERENCES tenants("Id"),
    "CreatedAtUtc" timestamptz NOT NULL DEFAULT now(), "UpdatedAtUtc" timestamptz NOT NULL DEFAULT now(),
    "CreatedBy" varchar(120), "UpdatedBy" varchar(120), "RowVersion" bytea NOT NULL DEFAULT decode('','hex'),
    "GoodsReceiptId" uuid NOT NULL REFERENCES goods_receipts("Id"), "LineNumber" integer NOT NULL,
    "ItemId" uuid NOT NULL REFERENCES items("Id"), "PurchaseOrderLineId" uuid REFERENCES purchase_order_lines("Id"),
    "InventoryLotId" uuid REFERENCES inventory_lots("Id"), "ReceivedQuantity" numeric(18,4) NOT NULL,
    "BaseUom" varchar(12) NOT NULL, "InspectionStatus" varchar(40) NOT NULL, "RejectionReason" text,
    UNIQUE ("TenantId","GoodsReceiptId","LineNumber")
);
CREATE TABLE IF NOT EXISTS material_test_certificates (
    "Id" uuid PRIMARY KEY, "TenantId" uuid NOT NULL REFERENCES tenants("Id"),
    "CreatedAtUtc" timestamptz NOT NULL DEFAULT now(), "UpdatedAtUtc" timestamptz NOT NULL DEFAULT now(),
    "CreatedBy" varchar(120), "UpdatedBy" varchar(120), "RowVersion" bytea NOT NULL DEFAULT decode('','hex'),
    "InventoryLotId" uuid NOT NULL REFERENCES inventory_lots("Id"), "CertificateNumber" varchar(100) NOT NULL,
    "CertificateType" varchar(40) NOT NULL, "Issuer" varchar(200) NOT NULL, "IssueDate" date, "DocumentUri" text,
    "VerificationStatus" varchar(40) NOT NULL, UNIQUE ("TenantId","InventoryLotId","CertificateNumber")
);
CREATE TABLE IF NOT EXISTS audit_events (
    "Id" uuid PRIMARY KEY, "TenantId" uuid NOT NULL REFERENCES tenants("Id"),
    "CreatedAtUtc" timestamptz NOT NULL DEFAULT now(), "UpdatedAtUtc" timestamptz NOT NULL DEFAULT now(),
    "CreatedBy" varchar(120), "UpdatedBy" varchar(120), "RowVersion" bytea NOT NULL DEFAULT decode('','hex'),
    "EntityName" varchar(160) NOT NULL, "EntityId" varchar(100) NOT NULL, "Action" varchar(80) NOT NULL,
    "ActorId" varchar(120) NOT NULL, "OccurredAtUtc" timestamptz NOT NULL, "CorrelationId" varchar(120),
    "BeforeJson" jsonb, "AfterJson" jsonb
);
CREATE INDEX IF NOT EXISTS ix_audit_events_tenant_occurred ON audit_events("TenantId","OccurredAtUtc");

COMMIT;
