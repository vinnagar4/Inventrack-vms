# INVENTRACK VMS™ — Commit 002: Database & EF Core Foundation

This package adds the initial PostgreSQL persistence layer for the INVENTRACK VMS inventory-management solution.

> **Integration note:** This is a focused Commit 002 database foundation package. The earlier Commit 001 repository bootstrap was not available to inspect in this session, so these files are packaged as a self-contained backend project rather than claiming an unverified merge into your GitHub repository.

## Included
- ASP.NET Core 9 Web API project
- EF Core 9 + Npgsql PostgreSQL provider
- Tenant-aware entities and query-filter foundation
- Inventory, warehouse/bin, item, lot, supplier, purchase order, goods receipt, MTC and audit-event models
- EF Core initial migration and PostgreSQL SQL migration
- Development seed data (opt-in)
- Health endpoint and database readiness endpoint
- Configuration sample and Docker Compose PostgreSQL service

## Requirements
- .NET SDK 9.0
- Docker Desktop (optional, for local PostgreSQL)

## Run locally
1. Copy `src/Inventrack.Vms.Api/appsettings.Development.example.json` to `appsettings.Development.json`.
2. Start PostgreSQL with `docker compose up -d postgres`.
3. Set the connection string in `appsettings.Development.json` or the environment variable `ConnectionStrings__VmsDatabase`.
4. From this directory run:

   ```bash
   dotnet restore src/Inventrack.Vms.Api/Inventrack.Vms.Api.csproj
   dotnet tool install --global dotnet-ef --version 9.*
   dotnet ef migrations add InitialInventoryFoundation --project src/Inventrack.Vms.Api --startup-project src/Inventrack.Vms.Api
   dotnet ef database update --project src/Inventrack.Vms.Api --startup-project src/Inventrack.Vms.Api
   dotnet run --project src/Inventrack.Vms.Api
   ```

5. Check `GET /health` and `GET /health/ready`.

## Migration approach
`Migrations/README.md` documents how to generate the provider-specific EF Core migration and model snapshot. `database/001_initial_inventory_foundation.sql` is a readable SQL baseline for review and controlled DBA deployment. Use one migration mechanism per environment; do not apply both to the same database.

## Data-model notes
- All business tables carry a `TenantId` for tenant scoping.
- The EF query filter scopes tenant-owned rows when `ITenantContext.TenantId` is set. For a multi-tenant production deployment, authentication must establish the tenant context from trusted claims; never trust a client-supplied tenant ID.
- This commit is a persistence foundation, not the complete application. Authentication, authorization, workflow enforcement, and production hardening are subsequent commits.
- Inventory balances are an operational projection; all stock changes should be recorded as immutable inventory transactions in subsequent service-layer work.
- Quantities use `numeric(18,4)`; monetary values use `numeric(18,2)`.

## Project layout
```text
src/Inventrack.Vms.Api/
  Data/                 DbContext, tenant context, design-time factory
  Domain/                EF entities and enums
  Migrations/            Initial EF migration
  Program.cs
  appsettings.Development.example.json
database/
  001_initial_inventory_foundation.sql
```
