# EF Core migration generation

The C# domain and model configuration are the source of truth. Generate the provider-specific migration and snapshot locally after package restore:

```bash
dotnet ef migrations add InitialInventoryFoundation --project src/Inventrack.Vms.Api --startup-project src/Inventrack.Vms.Api
dotnet ef database update --project src/Inventrack.Vms.Api --startup-project src/Inventrack.Vms.Api
```

The accompanying `database/001_initial_inventory_foundation.sql` is a DBA-reviewable SQL baseline. This package intentionally does not misrepresent hand-authored SQL as EF-generated migration metadata. Before treating this commit as production-ready, generate and test the EF migration and snapshot.
