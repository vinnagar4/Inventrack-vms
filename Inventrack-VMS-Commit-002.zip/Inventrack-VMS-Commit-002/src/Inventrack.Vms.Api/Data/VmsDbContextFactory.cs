using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace Inventrack.Vms.Data;

public sealed class VmsDbContextFactory : IDesignTimeDbContextFactory<VmsDbContext>
{
    public VmsDbContext CreateDbContext(string[] args)
    {
        var connectionString = Environment.GetEnvironmentVariable("ConnectionStrings__VmsDatabase")
            ?? "Host=localhost;Port=5432;Database=inventrack_vms;Username=inventrack;Password=change_me_local_only";
        var options = new DbContextOptionsBuilder<VmsDbContext>()
            .UseNpgsql(connectionString)
            .Options;
        return new VmsDbContext(options, new DesignTimeTenantContext());
    }

    private sealed class DesignTimeTenantContext : ITenantContext
    {
        public Guid? TenantId => null;
    }
}
