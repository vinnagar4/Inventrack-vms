namespace Inventrack.Vms.Data;

/// <summary>
/// Tenant identity must be resolved from authenticated server-side claims in the auth commit.
/// Never populate this from an untrusted request body or query parameter.
/// </summary>
public interface ITenantContext
{
    Guid? TenantId { get; }
}

public sealed class DevelopmentTenantContext : ITenantContext
{
    public Guid? TenantId { get; set; }
}
