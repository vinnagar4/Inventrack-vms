using Inventrack.Vms.Domain;
using Microsoft.EntityFrameworkCore;

namespace Inventrack.Vms.Data;

public sealed class VmsDbContext(
    DbContextOptions<VmsDbContext> options,
    ITenantContext tenantContext) : DbContext(options)
{
    public DbSet<Tenant> Tenants => Set<Tenant>();
    public DbSet<Site> Sites => Set<Site>();
    public DbSet<Item> Items => Set<Item>();
    public DbSet<Warehouse> Warehouses => Set<Warehouse>();
    public DbSet<BinLocation> BinLocations => Set<BinLocation>();
    public DbSet<InventoryLot> InventoryLots => Set<InventoryLot>();
    public DbSet<InventoryBalance> InventoryBalances => Set<InventoryBalance>();
    public DbSet<InventoryTransaction> InventoryTransactions => Set<InventoryTransaction>();
    public DbSet<Supplier> Suppliers => Set<Supplier>();
    public DbSet<PurchaseOrder> PurchaseOrders => Set<PurchaseOrder>();
    public DbSet<PurchaseOrderLine> PurchaseOrderLines => Set<PurchaseOrderLine>();
    public DbSet<GoodsReceipt> GoodsReceipts => Set<GoodsReceipt>();
    public DbSet<GoodsReceiptLine> GoodsReceiptLines => Set<GoodsReceiptLine>();
    public DbSet<MaterialTestCertificate> MaterialTestCertificates => Set<MaterialTestCertificate>();
    public DbSet<AuditEvent> AuditEvents => Set<AuditEvent>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<Tenant>(e =>
        {
            e.ToTable("tenants");
            e.HasKey(x => x.Id);
            e.Property(x => x.Code).HasMaxLength(40).IsRequired();
            e.Property(x => x.Name).HasMaxLength(200).IsRequired();
            e.HasIndex(x => x.Code).IsUnique();
        });

        ConfigureTenantEntity<Site>(modelBuilder, "sites");
        ConfigureTenantEntity<Item>(modelBuilder, "items");
        ConfigureTenantEntity<Warehouse>(modelBuilder, "warehouses");
        ConfigureTenantEntity<BinLocation>(modelBuilder, "bin_locations");
        ConfigureTenantEntity<InventoryLot>(modelBuilder, "inventory_lots");
        ConfigureTenantEntity<InventoryBalance>(modelBuilder, "inventory_balances");
        ConfigureTenantEntity<InventoryTransaction>(modelBuilder, "inventory_transactions");
        ConfigureTenantEntity<Supplier>(modelBuilder, "suppliers");
        ConfigureTenantEntity<PurchaseOrder>(modelBuilder, "purchase_orders");
        ConfigureTenantEntity<PurchaseOrderLine>(modelBuilder, "purchase_order_lines");
        ConfigureTenantEntity<GoodsReceipt>(modelBuilder, "goods_receipts");
        ConfigureTenantEntity<GoodsReceiptLine>(modelBuilder, "goods_receipt_lines");
        ConfigureTenantEntity<MaterialTestCertificate>(modelBuilder, "material_test_certificates");
        ConfigureTenantEntity<AuditEvent>(modelBuilder, "audit_events");

        modelBuilder.Entity<Item>(e =>
        {
            e.Property(x => x.Code).HasMaxLength(80).IsRequired();
            e.Property(x => x.Description).HasMaxLength(500).IsRequired();
            e.Property(x => x.Category).HasMaxLength(40).IsRequired();
            e.Property(x => x.BaseUom).HasMaxLength(12).IsRequired();
            e.HasIndex(x => new { x.TenantId, x.Code }).IsUnique();
            e.ToTable(t => t.HasCheckConstraint("ck_items_shelf_life_positive",
                "\"ShelfLifeDays\" IS NULL OR \"ShelfLifeDays\" > 0"));
        });
        modelBuilder.Entity<Site>().HasIndex(x => new { x.TenantId, x.Code }).IsUnique();
        modelBuilder.Entity<Warehouse>().HasIndex(x => new { x.TenantId, x.SiteId, x.Code }).IsUnique();
        modelBuilder.Entity<BinLocation>().HasIndex(x => new { x.TenantId, x.WarehouseId, x.Code }).IsUnique();
        modelBuilder.Entity<InventoryLot>().HasIndex(x => new { x.TenantId, x.ItemId, x.LotNumber }).IsUnique();
        modelBuilder.Entity<InventoryBalance>(e =>
        {
            e.Property(x => x.QuantityOnHand).HasPrecision(18, 4);
            e.Property(x => x.QuantityAllocated).HasPrecision(18, 4);
            e.Property(x => x.BaseUom).HasMaxLength(12);
            e.HasIndex(x => new { x.TenantId, x.ItemId, x.WarehouseId, x.BinLocationId, x.InventoryLotId, x.Status }).IsUnique();
            e.ToTable(t => t.HasCheckConstraint("ck_inventory_balance_nonnegative",
                "\"QuantityOnHand\" >= 0 AND \"QuantityAllocated\" >= 0 AND \"QuantityAllocated\" <= \"QuantityOnHand\""));
        });
        modelBuilder.Entity<InventoryTransaction>(e =>
        {
            e.Property(x => x.Quantity).HasPrecision(18, 4);
            e.Property(x => x.TransactionNumber).HasMaxLength(80).IsRequired();
            e.HasIndex(x => new { x.TenantId, x.TransactionNumber }).IsUnique();
            e.HasIndex(x => new { x.TenantId, x.ItemId, x.PostedAtUtc });
        });
        modelBuilder.Entity<Supplier>(e =>
        {
            e.Property(x => x.Code).HasMaxLength(80).IsRequired();
            e.Property(x => x.Name).HasMaxLength(250).IsRequired();
            e.HasIndex(x => new { x.TenantId, x.Code }).IsUnique();
        });
        modelBuilder.Entity<PurchaseOrder>(e =>
        {
            e.Property(x => x.OrderNumber).HasMaxLength(80).IsRequired();
            e.Property(x => x.CurrencyCode).HasMaxLength(3).IsRequired();
            e.Property(x => x.TotalAmount).HasPrecision(18, 2);
            e.HasIndex(x => new { x.TenantId, x.OrderNumber }).IsUnique();
            e.HasMany(x => x.Lines).WithOne().HasForeignKey(x => x.PurchaseOrderId).OnDelete(DeleteBehavior.Restrict);
        });
        modelBuilder.Entity<PurchaseOrderLine>(e =>
        {
            e.Property(x => x.OrderedQuantity).HasPrecision(18, 4);
            e.Property(x => x.ReceivedQuantity).HasPrecision(18, 4);
            e.Property(x => x.UnitPrice).HasPrecision(18, 2);
            e.HasIndex(x => new { x.TenantId, x.PurchaseOrderId, x.LineNumber }).IsUnique();
        });
        modelBuilder.Entity<GoodsReceipt>(e =>
        {
            e.Property(x => x.ReceiptNumber).HasMaxLength(80).IsRequired();
            e.HasIndex(x => new { x.TenantId, x.ReceiptNumber }).IsUnique();
            e.HasMany(x => x.Lines).WithOne().HasForeignKey(x => x.GoodsReceiptId).OnDelete(DeleteBehavior.Restrict);
        });
        modelBuilder.Entity<GoodsReceiptLine>(e =>
        {
            e.Property(x => x.ReceivedQuantity).HasPrecision(18, 4);
            e.HasIndex(x => new { x.TenantId, x.GoodsReceiptId, x.LineNumber }).IsUnique();
        });
        modelBuilder.Entity<MaterialTestCertificate>(e =>
        {
            e.Property(x => x.CertificateNumber).HasMaxLength(100).IsRequired();
            e.HasIndex(x => new { x.TenantId, x.InventoryLotId, x.CertificateNumber }).IsUnique();
        });
        modelBuilder.Entity<AuditEvent>(e =>
        {
            e.Property(x => x.EntityName).HasMaxLength(160).IsRequired();
            e.Property(x => x.EntityId).HasMaxLength(100).IsRequired();
            e.Property(x => x.Action).HasMaxLength(80).IsRequired();
            e.HasIndex(x => new { x.TenantId, x.OccurredAtUtc });
        });

        // Tenant scoping is enabled only when a tenant has been established by trusted middleware.
        // Migration and background-job paths can intentionally run without a tenant context.
        modelBuilder.Entity<Site>().HasQueryFilter(x => tenantContext.TenantId == null || x.TenantId == tenantContext.TenantId);
        modelBuilder.Entity<Item>().HasQueryFilter(x => tenantContext.TenantId == null || x.TenantId == tenantContext.TenantId);
        modelBuilder.Entity<Warehouse>().HasQueryFilter(x => tenantContext.TenantId == null || x.TenantId == tenantContext.TenantId);
        modelBuilder.Entity<BinLocation>().HasQueryFilter(x => tenantContext.TenantId == null || x.TenantId == tenantContext.TenantId);
        modelBuilder.Entity<InventoryLot>().HasQueryFilter(x => tenantContext.TenantId == null || x.TenantId == tenantContext.TenantId);
        modelBuilder.Entity<InventoryBalance>().HasQueryFilter(x => tenantContext.TenantId == null || x.TenantId == tenantContext.TenantId);
        modelBuilder.Entity<InventoryTransaction>().HasQueryFilter(x => tenantContext.TenantId == null || x.TenantId == tenantContext.TenantId);
        modelBuilder.Entity<Supplier>().HasQueryFilter(x => tenantContext.TenantId == null || x.TenantId == tenantContext.TenantId);
        modelBuilder.Entity<PurchaseOrder>().HasQueryFilter(x => tenantContext.TenantId == null || x.TenantId == tenantContext.TenantId);
        modelBuilder.Entity<PurchaseOrderLine>().HasQueryFilter(x => tenantContext.TenantId == null || x.TenantId == tenantContext.TenantId);
        modelBuilder.Entity<GoodsReceipt>().HasQueryFilter(x => tenantContext.TenantId == null || x.TenantId == tenantContext.TenantId);
        modelBuilder.Entity<GoodsReceiptLine>().HasQueryFilter(x => tenantContext.TenantId == null || x.TenantId == tenantContext.TenantId);
        modelBuilder.Entity<MaterialTestCertificate>().HasQueryFilter(x => tenantContext.TenantId == null || x.TenantId == tenantContext.TenantId);
        modelBuilder.Entity<AuditEvent>().HasQueryFilter(x => tenantContext.TenantId == null || x.TenantId == tenantContext.TenantId);
    }

    private static void ConfigureTenantEntity<TEntity>(ModelBuilder modelBuilder, string tableName)
        where TEntity : TenantEntity
    {
        modelBuilder.Entity<TEntity>(e =>
        {
            e.ToTable(tableName);
            e.HasKey(x => x.Id);
            e.Property(x => x.TenantId).IsRequired();
            e.Property(x => x.CreatedAtUtc).IsRequired();
            e.Property(x => x.UpdatedAtUtc).IsRequired();
            e.Property(x => x.CreatedBy).HasMaxLength(120);
            e.Property(x => x.UpdatedBy).HasMaxLength(120);
            e.Property(x => x.RowVersion).IsRowVersion();
            e.HasIndex(x => new { x.TenantId, x.Id });
        });
    }

    public override int SaveChanges()
    {
        StampEntities();
        return base.SaveChanges();
    }

    public override Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        StampEntities();
        return base.SaveChangesAsync(cancellationToken);
    }

    private void StampEntities()
    {
        var now = DateTimeOffset.UtcNow;
        foreach (var entry in ChangeTracker.Entries<TenantEntity>())
        {
            if (entry.State == EntityState.Added)
            {
                entry.Entity.CreatedAtUtc = now;
                entry.Entity.UpdatedAtUtc = now;
            }
            else if (entry.State == EntityState.Modified)
            {
                entry.Entity.UpdatedAtUtc = now;
            }
        }
    }
}
