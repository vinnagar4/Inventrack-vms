namespace Inventrack.Vms.Domain;

public abstract class TenantEntity
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid TenantId { get; set; }
    public DateTimeOffset CreatedAtUtc { get; set; } = DateTimeOffset.UtcNow;
    public DateTimeOffset UpdatedAtUtc { get; set; } = DateTimeOffset.UtcNow;
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
    public byte[] RowVersion { get; set; } = [];
}

public sealed class Tenant
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public bool IsActive { get; set; } = true;
    public DateTimeOffset CreatedAtUtc { get; set; } = DateTimeOffset.UtcNow;
}

public sealed class Site : TenantEntity
{
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public string? TimeZoneId { get; set; }
    public bool IsActive { get; set; } = true;
}

public sealed class Item : TenantEntity
{
    public string Code { get; set; } = "";
    public string Description { get; set; } = "";
    public string Category { get; set; } = "RAW_MATERIAL";
    public string BaseUom { get; set; } = "EA";
    public string? MaterialGrade { get; set; }
    public bool IsTraceabilityRequired { get; set; } = true;
    public bool IsShelfLifeControlled { get; set; }
    public int? ShelfLifeDays { get; set; }
    public bool IsActive { get; set; } = true;
}

public sealed class Warehouse : TenantEntity
{
    public Guid SiteId { get; set; }
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public bool IsActive { get; set; } = true;
}

public sealed class BinLocation : TenantEntity
{
    public Guid WarehouseId { get; set; }
    public string Code { get; set; } = "";
    public string ZoneCode { get; set; } = "";
    public string? Aisle { get; set; }
    public string? Rack { get; set; }
    public string? Level { get; set; }
    public string? Bin { get; set; }
    public decimal? CapacityQuantity { get; set; }
    public bool IsQuarantine { get; set; }
    public bool IsActive { get; set; } = true;
}

public enum InventoryStatus
{
    Free = 1, Allocated = 2, QaHold = 3, Quarantine = 4,
    CustomerFreeIssue = 5, Rework = 6, Scrap = 7, Consignment = 8
}

public sealed class InventoryLot : TenantEntity
{
    public Guid ItemId { get; set; }
    public string LotNumber { get; set; } = "";
    public string? HeatNumber { get; set; }
    public string? SupplierLotNumber { get; set; }
    public DateOnly? ManufactureDate { get; set; }
    public DateOnly? CureDate { get; set; }
    public DateOnly? ExpiryDate { get; set; }
    public string? CountryOfOrigin { get; set; }
    public string? MaterialTestCertificateNumber { get; set; }
    public string QualityStatus { get; set; } = "PENDING_INSPECTION";
}

public sealed class InventoryBalance : TenantEntity
{
    public Guid ItemId { get; set; }
    public Guid WarehouseId { get; set; }
    public Guid BinLocationId { get; set; }
    public Guid? InventoryLotId { get; set; }
    public InventoryStatus Status { get; set; } = InventoryStatus.Free;
    public decimal QuantityOnHand { get; set; }
    public decimal QuantityAllocated { get; set; }
    public string BaseUom { get; set; } = "EA";
}

public sealed class InventoryTransaction : TenantEntity
{
    public string TransactionNumber { get; set; } = "";
    public string TransactionType { get; set; } = "";
    public Guid ItemId { get; set; }
    public Guid? InventoryLotId { get; set; }
    public Guid? FromWarehouseId { get; set; }
    public Guid? FromBinLocationId { get; set; }
    public Guid? ToWarehouseId { get; set; }
    public Guid? ToBinLocationId { get; set; }
    public decimal Quantity { get; set; }
    public string BaseUom { get; set; } = "EA";
    public string ReferenceType { get; set; } = "";
    public string? ReferenceNumber { get; set; }
    public DateTimeOffset PostedAtUtc { get; set; } = DateTimeOffset.UtcNow;
    public string PostedBy { get; set; } = "system";
    public string? ReasonCode { get; set; }
}

public sealed class Supplier : TenantEntity
{
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public string? TaxRegistrationNumber { get; set; }
    public string? CountryCode { get; set; }
    public string? Email { get; set; }
    public string? Phone { get; set; }
    public bool IsApproved { get; set; }
    public bool IsActive { get; set; } = true;
}

public sealed class PurchaseOrder : TenantEntity
{
    public string OrderNumber { get; set; } = "";
    public Guid SupplierId { get; set; }
    public Guid SiteId { get; set; }
    public DateOnly OrderDate { get; set; }
    public DateOnly? ExpectedDate { get; set; }
    public string CurrencyCode { get; set; } = "INR";
    public string Status { get; set; } = "DRAFT";
    public decimal TotalAmount { get; set; }
    public List<PurchaseOrderLine> Lines { get; set; } = [];
}

public sealed class PurchaseOrderLine : TenantEntity
{
    public Guid PurchaseOrderId { get; set; }
    public int LineNumber { get; set; }
    public Guid ItemId { get; set; }
    public decimal OrderedQuantity { get; set; }
    public decimal ReceivedQuantity { get; set; }
    public decimal UnitPrice { get; set; }
    public string BaseUom { get; set; } = "EA";
    public DateOnly? RequiredDate { get; set; }
    public string? ProjectCode { get; set; }
}

public sealed class GoodsReceipt : TenantEntity
{
    public string ReceiptNumber { get; set; } = "";
    public Guid SupplierId { get; set; }
    public Guid? PurchaseOrderId { get; set; }
    public Guid WarehouseId { get; set; }
    public DateTimeOffset ReceivedAtUtc { get; set; } = DateTimeOffset.UtcNow;
    public string SupplierDeliveryNote { get; set; } = "";
    public string Status { get; set; } = "DRAFT";
    public List<GoodsReceiptLine> Lines { get; set; } = [];
}

public sealed class GoodsReceiptLine : TenantEntity
{
    public Guid GoodsReceiptId { get; set; }
    public int LineNumber { get; set; }
    public Guid ItemId { get; set; }
    public Guid? PurchaseOrderLineId { get; set; }
    public Guid? InventoryLotId { get; set; }
    public decimal ReceivedQuantity { get; set; }
    public string BaseUom { get; set; } = "EA";
    public string InspectionStatus { get; set; } = "PENDING";
    public string? RejectionReason { get; set; }
}

public sealed class MaterialTestCertificate : TenantEntity
{
    public Guid InventoryLotId { get; set; }
    public string CertificateNumber { get; set; } = "";
    public string CertificateType { get; set; } = "EN10204_3_1";
    public string Issuer { get; set; } = "";
    public DateOnly? IssueDate { get; set; }
    public string? DocumentUri { get; set; }
    public string VerificationStatus { get; set; } = "PENDING";
}

public sealed class AuditEvent : TenantEntity
{
    public string EntityName { get; set; } = "";
    public string EntityId { get; set; } = "";
    public string Action { get; set; } = "";
    public string ActorId { get; set; } = "system";
    public DateTimeOffset OccurredAtUtc { get; set; } = DateTimeOffset.UtcNow;
    public string? CorrelationId { get; set; }
    public string? BeforeJson { get; set; }
    public string? AfterJson { get; set; }
}
