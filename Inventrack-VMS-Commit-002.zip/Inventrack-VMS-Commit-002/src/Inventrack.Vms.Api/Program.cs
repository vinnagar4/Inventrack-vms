using Inventrack.Vms.Data;
using Inventrack.Vms.Domain;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);
var connectionString = builder.Configuration.GetConnectionString("VmsDatabase")
    ?? throw new InvalidOperationException("ConnectionStrings:VmsDatabase is required.");

builder.Services.AddSingleton<DevelopmentTenantContext>();
builder.Services.AddSingleton<ITenantContext>(sp => sp.GetRequiredService<DevelopmentTenantContext>());
builder.Services.AddDbContext<VmsDbContext>(options => options.UseNpgsql(connectionString));
builder.Services.AddHealthChecks().AddDbContextCheck<VmsDbContext>("postgresql");
builder.Services.AddEndpointsApiExplorer();

var app = builder.Build();

app.MapGet("/health", () => Results.Ok(new { status = "healthy", service = "INVENTRACK VMS API" }));
app.MapGet("/health/ready", async (VmsDbContext db, CancellationToken ct) =>
{
    try
    {
        return await db.Database.CanConnectAsync(ct)
            ? Results.Ok(new { status = "ready", database = "connected" })
            : Results.StatusCode(StatusCodes.Status503ServiceUnavailable);
    }
    catch
    {
        return Results.StatusCode(StatusCodes.Status503ServiceUnavailable);
    }
});
app.MapGet("/api/v1/meta/database", (IConfiguration cfg) => Results.Ok(new
{
    provider = "PostgreSQL",
    schemaVersion = "001_initial_inventory_foundation",
    seedEnabled = cfg.GetValue<bool>("SeedDevelopmentData")
}));

if (app.Configuration.GetValue<bool>("SeedDevelopmentData") && app.Environment.IsDevelopment())
{
    await using var scope = app.Services.CreateAsyncScope();
    var db = scope.ServiceProvider.GetRequiredService<VmsDbContext>();
    await db.Database.MigrateAsync();

    if (!await db.Tenants.AnyAsync())
    {
        var tenantId = Guid.Parse("10000000-0000-4000-8000-000000000001");
        db.Tenants.Add(new Tenant
        {
            Id = tenantId,
            Code = "DEMO",
            Name = "INVENTRACK Demo Industries Pvt. Ltd."
        });
        db.Sites.Add(new Site
        {
            Id = Guid.Parse("20000000-0000-4000-8000-000000000001"),
            TenantId = tenantId,
            Code = "MAIN",
            Name = "Main Manufacturing Site",
            TimeZoneId = "Asia/Kolkata"
        });
        db.Items.AddRange(
            new Item { TenantId = tenantId, Code = "RM-SS316-001", Description = "Stainless steel 316 casting", Category = "RAW_MATERIAL", BaseUom = "KG", MaterialGrade = "SS316", IsTraceabilityRequired = true },
            new Item { TenantId = tenantId, Code = "SEAL-PTFE-001", Description = "PTFE seat ring", Category = "BOUGHT_OUT", BaseUom = "EA", IsTraceabilityRequired = true, IsShelfLifeControlled = true, ShelfLifeDays = 1825 }
        );
        await db.SaveChangesAsync();
    }
}

app.Run();

public partial class Program;
