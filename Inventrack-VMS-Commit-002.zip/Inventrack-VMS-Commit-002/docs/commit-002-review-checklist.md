# Commit 002 review checklist

- [ ] Confirm Commit 001 baseline and merge these files into the canonical repository.
- [ ] Restore packages with .NET SDK 9.
- [ ] Run `dotnet build src/Inventrack.Vms.Api`.
- [ ] Start PostgreSQL and apply exactly one migration path.
- [ ] Verify `/health` and `/health/ready`.
- [ ] Verify tenant query filtering after authentication middleware establishes a trusted tenant ID.
- [ ] Add integration tests for migrations, unique constraints, balance checks, and tenant isolation.
- [ ] Review schema against the complete BRD and the organization's retention, security, and audit policies.
- [ ] Generate/verify an EF migration snapshot with `dotnet ef migrations add` if changing the model.
- [ ] Commit only after build and database integration tests pass.
