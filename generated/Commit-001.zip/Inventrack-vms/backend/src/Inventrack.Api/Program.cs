using Inventrack.Api.Extensions;
using Serilog;

Log.Logger = new LoggerConfiguration()
    .WriteTo.Console()
    .CreateBootstrapLogger();

try
{
    var builder = WebApplication.CreateBuilder(args);
    builder.Host.UseSerilog((context, services, configuration) => configuration
        .ReadFrom.Configuration(context.Configuration)
        .ReadFrom.Services(services)
        .Enrich.FromLogContext()
        .WriteTo.Console());

    builder.Services.AddInventrackApi();

    var app = builder.Build();
    app.UseInventrackApi();
    app.Run();
}
catch (Exception exception)
{
    Log.Fatal(exception, "Inventrack API terminated unexpectedly");
}
finally
{
    Log.CloseAndFlush();
}

/// <summary>Application entry-point marker for integration tooling.</summary>
public partial class Program;
