using Microsoft.AspNetCore.Mvc;

namespace Inventrack.Api.Controllers;

/// <summary>Provides lightweight service status information.</summary>
[ApiController]
[Route("api/status")]
public sealed class StatusController : ControllerBase
{
    /// <summary>Returns the current service status.</summary>
    [HttpGet]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public IActionResult Get() => Ok(new { service = "Inventrack API", status = "healthy" });
}
