namespace Inventrack.Api.Extensions;

/// <summary>Configures the HTTP request pipeline.</summary>
public static class WebApplicationExtensions
{
    /// <summary>Configures the baseline API endpoints and middleware.</summary>
    public static WebApplication UseInventrackApi(this WebApplication app)
    {
        app.UseSerilogRequestLogging();

        if (app.Environment.IsDevelopment())
        {
            app.UseSwagger();
            app.UseSwaggerUI();
        }

        app.UseHttpsRedirection();
        app.MapControllers();
        app.MapHealthChecks("/health");
        app.MapGet("/", () => Results.Ok(new { service = "Inventrack API", status = "healthy" }));

        return app;
    }
}
