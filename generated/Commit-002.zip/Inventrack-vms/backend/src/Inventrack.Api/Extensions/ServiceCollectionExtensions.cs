using Inventrack.Infrastructure;

namespace Inventrack.Api.Extensions;

/// <summary>Registers HTTP-facing application services.</summary>
public static class ServiceCollectionExtensions
{
    /// <summary>Registers the baseline API services.</summary>
    public static IServiceCollection AddInventrackApi(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddControllers();
        services.AddEndpointsApiExplorer();
        services.AddSwaggerGen();
        services.AddHealthChecks();
        services.AddInventrackInfrastructure(configuration);

        return services;
    }
}
