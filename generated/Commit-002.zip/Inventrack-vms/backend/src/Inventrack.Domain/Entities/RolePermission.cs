namespace Inventrack.Domain.Entities;

/// <summary>Links a role to a permission.</summary>
public sealed class RolePermission
{
    /// <summary>Gets or sets the role identifier.</summary>
    public Guid RoleId { get; set; }

    /// <summary>Gets or sets the permission identifier.</summary>
    public Guid PermissionId { get; set; }

    /// <summary>Gets or sets the linked role.</summary>
    public Role? Role { get; set; }

    /// <summary>Gets or sets the linked permission.</summary>
    public Permission? Permission { get; set; }
}
