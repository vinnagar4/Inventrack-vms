using Inventrack.Domain.Common;

namespace Inventrack.Domain.Entities;

/// <summary>Represents a physical facility operated by a company.</summary>
public sealed class Plant : BaseEntity
{
    /// <summary>Gets or sets the owning company identifier.</summary>
    public Guid CompanyId { get; set; }

    /// <summary>Gets or sets the plant name.</summary>
    public string Name { get; set; } = string.Empty;

    /// <summary>Gets or sets the unique code within its company.</summary>
    public string Code { get; set; } = string.Empty;

    /// <summary>Gets or sets the optional street address.</summary>
    public string? Address { get; set; }

    /// <summary>Gets or sets whether the plant is active.</summary>
    public bool IsActive { get; set; } = true;

    /// <summary>Gets or sets the owning company.</summary>
    public Company? Company { get; set; }
}
