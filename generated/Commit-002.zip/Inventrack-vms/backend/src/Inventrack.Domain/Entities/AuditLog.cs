using Inventrack.Domain.Common;

namespace Inventrack.Domain.Entities;

/// <summary>Records a business-relevant action for traceability.</summary>
public sealed class AuditLog : BaseEntity
{
    /// <summary>Gets or sets the optional actor identifier.</summary>
    public Guid? UserId { get; set; }

    /// <summary>Gets or sets the optional user that performed the action.</summary>
    public ApplicationUser? User { get; set; }

    /// <summary>Gets or sets the action that occurred.</summary>
    public string Action { get; set; } = string.Empty;

    /// <summary>Gets or sets the affected entity type.</summary>
    public string EntityType { get; set; } = string.Empty;

    /// <summary>Gets or sets the affected entity identifier.</summary>
    public Guid? EntityId { get; set; }

    /// <summary>Gets or sets optional JSON details.</summary>
    public string? DetailsJson { get; set; }
}
