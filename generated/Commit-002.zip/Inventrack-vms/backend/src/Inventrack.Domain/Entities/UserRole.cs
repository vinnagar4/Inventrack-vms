namespace Inventrack.Domain.Entities;

/// <summary>Links an application user to a role.</summary>
public sealed class UserRole
{
    /// <summary>Gets or sets the user identifier.</summary>
    public Guid UserId { get; set; }

    /// <summary>Gets or sets the role identifier.</summary>
    public Guid RoleId { get; set; }

    /// <summary>Gets or sets the linked user.</summary>
    public ApplicationUser? User { get; set; }

    /// <summary>Gets or sets the linked role.</summary>
    public Role? Role { get; set; }
}
