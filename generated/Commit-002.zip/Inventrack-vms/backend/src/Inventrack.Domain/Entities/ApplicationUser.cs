using Inventrack.Domain.Common;

namespace Inventrack.Domain.Entities;

/// <summary>Represents a user account managed by the application.</summary>
public sealed class ApplicationUser : BaseEntity
{
    /// <summary>Gets or sets the user's email address.</summary>
    public string Email { get; set; } = string.Empty;

    /// <summary>Gets or sets the user-facing display name.</summary>
    public string DisplayName { get; set; } = string.Empty;

    /// <summary>Gets or sets the password hash. Authentication implementation follows in Commit 3.</summary>
    public string PasswordHash { get; set; } = string.Empty;

    /// <summary>Gets or sets the optional company scope.</summary>
    public Guid? CompanyId { get; set; }

    /// <summary>Gets or sets the optional company scope.</summary>
    public Company? Company { get; set; }

    /// <summary>Gets or sets whether this account can sign in.</summary>
    public bool IsActive { get; set; } = true;

    /// <summary>Gets the roles assigned to the user.</summary>
    public ICollection<UserRole> UserRoles { get; } = new List<UserRole>();

    /// <summary>Gets the audit records produced by this user.</summary>
    public ICollection<AuditLog> AuditLogs { get; } = new List<AuditLog>();
}
