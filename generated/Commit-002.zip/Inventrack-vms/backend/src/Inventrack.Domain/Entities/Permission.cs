using Inventrack.Domain.Common;

namespace Inventrack.Domain.Entities;

/// <summary>Represents an atomic action that can be granted to a role.</summary>
public sealed class Permission : BaseEntity
{
    /// <summary>Gets or sets the stable permission key.</summary>
    public string Key { get; set; } = string.Empty;

    /// <summary>Gets or sets a human-readable description.</summary>
    public string Description { get; set; } = string.Empty;

    /// <summary>Gets the roles granted this permission.</summary>
    public ICollection<RolePermission> RolePermissions { get; } = new List<RolePermission>();
}
