using Inventrack.Domain.Common;

namespace Inventrack.Domain.Entities;

/// <summary>Represents a named collection of permissions.</summary>
public sealed class Role : BaseEntity
{
    /// <summary>Gets or sets the role name.</summary>
    public string Name { get; set; } = string.Empty;

    /// <summary>Gets or sets an optional description.</summary>
    public string? Description { get; set; }

    /// <summary>Gets the permissions granted through this role.</summary>
    public ICollection<RolePermission> RolePermissions { get; } = new List<RolePermission>();

    /// <summary>Gets the users assigned to this role.</summary>
    public ICollection<UserRole> UserRoles { get; } = new List<UserRole>();
}
