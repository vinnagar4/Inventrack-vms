using Inventrack.Domain.Common;

namespace Inventrack.Domain.Entities;

/// <summary>Represents a tenant company operating in Inventrack.</summary>
public sealed class Company : BaseEntity
{
    /// <summary>Gets or sets the legal company name.</summary>
    public string Name { get; set; } = string.Empty;

    /// <summary>Gets or sets the unique business code.</summary>
    public string Code { get; set; } = string.Empty;

    /// <summary>Gets or sets whether the company is active.</summary>
    public bool IsActive { get; set; } = true;

    /// <summary>Gets the plants that belong to this company.</summary>
    public ICollection<Plant> Plants { get; } = new List<Plant>();

    /// <summary>Gets the users whose access is scoped to this company.</summary>
    public ICollection<ApplicationUser> Users { get; } = new List<ApplicationUser>();
}
