namespace Inventrack.Domain.Common;

/// <summary>Base type for entities persisted by Inventrack.</summary>
public abstract class BaseEntity
{
    /// <summary>Gets or sets the unique identifier.</summary>
    public Guid Id { get; set; } = Guid.NewGuid();

    /// <summary>Gets or sets the UTC time at which the entity was created.</summary>
    public DateTimeOffset CreatedAtUtc { get; set; } = DateTimeOffset.UtcNow;

    /// <summary>Gets or sets the UTC time at which the entity was last updated.</summary>
    public DateTimeOffset? UpdatedAtUtc { get; set; }
}
