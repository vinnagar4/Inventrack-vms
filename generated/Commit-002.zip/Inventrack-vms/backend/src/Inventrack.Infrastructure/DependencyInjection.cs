using Inventrack.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Inventrack.Infrastructure;

/// <summary>Registers Infrastructure services.</summary>
public static class DependencyInjection
{
    /// <summary>Registers PostgreSQL persistence services.</summary>
    public static IServiceCollection AddInventrackInfrastructure(this IServiceCollection services, IConfiguration configuration)
    {
        var connectionString = configuration.GetConnectionString("InventrackDatabase")
            ?? throw new InvalidOperationException("Connection string 'InventrackDatabase' is not configured.");

        services.AddDbContext<InventrackDbContext>(options => options.UseNpgsql(connectionString));
        return services;
    }
}
