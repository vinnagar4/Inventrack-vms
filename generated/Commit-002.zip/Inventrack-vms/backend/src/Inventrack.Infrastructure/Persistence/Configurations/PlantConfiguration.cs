using Inventrack.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Inventrack.Infrastructure.Persistence.Configurations;

/// <summary>Maps <see cref="Plant"/> to PostgreSQL.</summary>
public sealed class PlantConfiguration : IEntityTypeConfiguration<Plant>
{
    /// <inheritdoc />
    public void Configure(EntityTypeBuilder<Plant> builder)
    {
        builder.ToTable("plants");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.Name).HasMaxLength(200).IsRequired();
        builder.Property(x => x.Code).HasMaxLength(50).IsRequired();
        builder.Property(x => x.Address).HasMaxLength(500);
        builder.HasIndex(x => new { x.CompanyId, x.Code }).IsUnique();
        builder.Property(x => x.CreatedAtUtc).IsRequired();
    }
}
