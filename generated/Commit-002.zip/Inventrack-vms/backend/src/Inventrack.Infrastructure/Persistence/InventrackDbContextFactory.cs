using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace Inventrack.Infrastructure.Persistence;

/// <summary>Provides a design-time context for EF Core migration tooling.</summary>
public sealed class InventrackDbContextFactory : IDesignTimeDbContextFactory<InventrackDbContext>
{
    /// <inheritdoc />
    public InventrackDbContext CreateDbContext(string[] args)
    {
        var connectionString = Environment.GetEnvironmentVariable("INVENTRACK_CONNECTION_STRING")
            ?? "Host=localhost;Port=5432;Database=inventrack;Username=postgres;Password=postgres";
        var options = new DbContextOptionsBuilder<InventrackDbContext>().UseNpgsql(connectionString).Options;
        return new InventrackDbContext(options);
    }
}
