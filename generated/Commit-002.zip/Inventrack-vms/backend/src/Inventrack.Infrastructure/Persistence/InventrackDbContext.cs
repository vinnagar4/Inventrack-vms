using Inventrack.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace Inventrack.Infrastructure.Persistence;

/// <summary>EF Core persistence context for Inventrack's operational data.</summary>
public sealed class InventrackDbContext(DbContextOptions<InventrackDbContext> options) : DbContext(options)
{
    /// <summary>Gets the companies query root.</summary>
    public DbSet<Company> Companies => Set<Company>();

    /// <summary>Gets the plants query root.</summary>
    public DbSet<Plant> Plants => Set<Plant>();

    /// <summary>Gets the application users query root.</summary>
    public DbSet<ApplicationUser> Users => Set<ApplicationUser>();

    /// <summary>Gets the roles query root.</summary>
    public DbSet<Role> Roles => Set<Role>();

    /// <summary>Gets the permissions query root.</summary>
    public DbSet<Permission> Permissions => Set<Permission>();

    /// <summary>Gets the audit log query root.</summary>
    public DbSet<AuditLog> AuditLogs => Set<AuditLog>();

    /// <inheritdoc />
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(InventrackDbContext).Assembly);
        modelBuilder.SeedBaselineAuthorization();
        base.OnModelCreating(modelBuilder);
    }

    /// <inheritdoc />
    public override int SaveChanges(bool acceptAllChangesOnSuccess)
    {
        UpdateTimestamps();
        return base.SaveChanges(acceptAllChangesOnSuccess);
    }

    /// <inheritdoc />
    public override Task<int> SaveChangesAsync(bool acceptAllChangesOnSuccess, CancellationToken cancellationToken = default)
    {
        UpdateTimestamps();
        return base.SaveChangesAsync(acceptAllChangesOnSuccess, cancellationToken);
    }

    private void UpdateTimestamps()
    {
        var timestamp = DateTimeOffset.UtcNow;
        foreach (var entry in ChangeTracker.Entries<Inventrack.Domain.Common.BaseEntity>())
        {
            if (entry.State == EntityState.Added)
            {
                entry.Entity.CreatedAtUtc = timestamp;
            }
            else if (entry.State == EntityState.Modified)
            {
                entry.Entity.UpdatedAtUtc = timestamp;
            }
        }
    }
}
