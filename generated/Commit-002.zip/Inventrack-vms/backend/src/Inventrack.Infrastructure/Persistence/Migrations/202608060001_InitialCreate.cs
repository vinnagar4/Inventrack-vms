using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Inventrack.Infrastructure.Persistence.Migrations;

/// <summary>Creates the initial Inventrack PostgreSQL schema and baseline authorization records.</summary>
public partial class InitialCreate : Migration
{
    /// <inheritdoc />
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.CreateTable(
            name: "companies",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "uuid", nullable: false),
                Name = table.Column<string>(type: "character varying(200)", maxLength: 200, nullable: false),
                Code = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: false),
                IsActive = table.Column<bool>(type: "boolean", nullable: false),
                CreatedAtUtc = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false),
                UpdatedAtUtc = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: true),
            },
            constraints: table => table.PrimaryKey("PK_companies", x => x.Id));

        migrationBuilder.CreateTable(
            name: "permissions",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "uuid", nullable: false),
                Key = table.Column<string>(type: "character varying(150)", maxLength: 150, nullable: false),
                Description = table.Column<string>(type: "character varying(500)", maxLength: 500, nullable: false),
                CreatedAtUtc = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false),
                UpdatedAtUtc = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: true),
            },
            constraints: table => table.PrimaryKey("PK_permissions", x => x.Id));

        migrationBuilder.CreateTable(
            name: "roles",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "uuid", nullable: false),
                Name = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: false),
                Description = table.Column<string>(type: "character varying(500)", maxLength: 500, nullable: true),
                CreatedAtUtc = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false),
                UpdatedAtUtc = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: true),
            },
            constraints: table => table.PrimaryKey("PK_roles", x => x.Id));

        migrationBuilder.CreateTable(
            name: "users",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "uuid", nullable: false),
                Email = table.Column<string>(type: "character varying(320)", maxLength: 320, nullable: false),
                DisplayName = table.Column<string>(type: "character varying(200)", maxLength: 200, nullable: false),
                PasswordHash = table.Column<string>(type: "character varying(500)", maxLength: 500, nullable: false),
                CompanyId = table.Column<Guid>(type: "uuid", nullable: true),
                IsActive = table.Column<bool>(type: "boolean", nullable: false),
                CreatedAtUtc = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false),
                UpdatedAtUtc = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: true),
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_users", x => x.Id);
                table.ForeignKey("FK_users_companies_CompanyId", x => x.CompanyId, "companies", "Id", onDelete: ReferentialAction.Restrict);
            });

        migrationBuilder.CreateTable(
            name: "plants",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "uuid", nullable: false),
                CompanyId = table.Column<Guid>(type: "uuid", nullable: false),
                Name = table.Column<string>(type: "character varying(200)", maxLength: 200, nullable: false),
                Code = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: false),
                Address = table.Column<string>(type: "character varying(500)", maxLength: 500, nullable: true),
                IsActive = table.Column<bool>(type: "boolean", nullable: false),
                CreatedAtUtc = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false),
                UpdatedAtUtc = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: true),
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_plants", x => x.Id);
                table.ForeignKey("FK_plants_companies_CompanyId", x => x.CompanyId, "companies", "Id", onDelete: ReferentialAction.Restrict);
            });

        migrationBuilder.CreateTable(
            name: "role_permissions",
            columns: table => new
            {
                RoleId = table.Column<Guid>(type: "uuid", nullable: false),
                PermissionId = table.Column<Guid>(type: "uuid", nullable: false),
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_role_permissions", x => new { x.RoleId, x.PermissionId });
                table.ForeignKey("FK_role_permissions_permissions_PermissionId", x => x.PermissionId, "permissions", "Id", onDelete: ReferentialAction.Cascade);
                table.ForeignKey("FK_role_permissions_roles_RoleId", x => x.RoleId, "roles", "Id", onDelete: ReferentialAction.Cascade);
            });

        migrationBuilder.CreateTable(
            name: "user_roles",
            columns: table => new
            {
                UserId = table.Column<Guid>(type: "uuid", nullable: false),
                RoleId = table.Column<Guid>(type: "uuid", nullable: false),
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_user_roles", x => new { x.UserId, x.RoleId });
                table.ForeignKey("FK_user_roles_roles_RoleId", x => x.RoleId, "roles", "Id", onDelete: ReferentialAction.Cascade);
                table.ForeignKey("FK_user_roles_users_UserId", x => x.UserId, "users", "Id", onDelete: ReferentialAction.Cascade);
            });

        migrationBuilder.CreateTable(
            name: "audit_logs",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "uuid", nullable: false),
                UserId = table.Column<Guid>(type: "uuid", nullable: true),
                Action = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: false),
                EntityType = table.Column<string>(type: "character varying(200)", maxLength: 200, nullable: false),
                EntityId = table.Column<Guid>(type: "uuid", nullable: true),
                DetailsJson = table.Column<string>(type: "jsonb", nullable: true),
                CreatedAtUtc = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false),
                UpdatedAtUtc = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: true),
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_audit_logs", x => x.Id);
                table.ForeignKey("FK_audit_logs_users_UserId", x => x.UserId, "users", "Id", onDelete: ReferentialAction.SetNull);
            });

        migrationBuilder.InsertData("permissions", new[] { "Id", "CreatedAtUtc", "Description", "Key", "UpdatedAtUtc" }, new object[,]
        {
            { new Guid("91fc5e70-5f0b-487c-b285-1a5489e4ffab"), new DateTimeOffset(2026, 1, 1, 0, 0, 0, TimeSpan.Zero), "Manage system settings and access control.", "system.manage", null },
            { new Guid("e6a5957c-cfbf-443c-996e-9c032a68c0d4"), new DateTimeOffset(2026, 1, 1, 0, 0, 0, TimeSpan.Zero), "Create and manage companies and plants.", "company.manage", null },
        });
        migrationBuilder.InsertData("roles", new[] { "Id", "CreatedAtUtc", "Description", "Name", "UpdatedAtUtc" }, new object[] { new Guid("3cb3323d-2485-4ccf-9de9-6b76c7629ea0"), new DateTimeOffset(2026, 1, 1, 0, 0, 0, TimeSpan.Zero), "Full access to Inventrack.", "Administrator", null });
        migrationBuilder.InsertData("role_permissions", new[] { "PermissionId", "RoleId" }, new object[,]
        {
            { new Guid("91fc5e70-5f0b-487c-b285-1a5489e4ffab"), new Guid("3cb3323d-2485-4ccf-9de9-6b76c7629ea0") },
            { new Guid("e6a5957c-cfbf-443c-996e-9c032a68c0d4"), new Guid("3cb3323d-2485-4ccf-9de9-6b76c7629ea0") },
        });

        migrationBuilder.CreateIndex("IX_audit_logs_EntityType_EntityId", "audit_logs", new[] { "EntityType", "EntityId" });
        migrationBuilder.CreateIndex("IX_audit_logs_UserId", "audit_logs", "UserId");
        migrationBuilder.CreateIndex("IX_companies_Code", "companies", "Code", unique: true);
        migrationBuilder.CreateIndex("IX_permissions_Key", "permissions", "Key", unique: true);
        migrationBuilder.CreateIndex("IX_plants_CompanyId_Code", "plants", new[] { "CompanyId", "Code" }, unique: true);
        migrationBuilder.CreateIndex("IX_role_permissions_PermissionId", "role_permissions", "PermissionId");
        migrationBuilder.CreateIndex("IX_roles_Name", "roles", "Name", unique: true);
        migrationBuilder.CreateIndex("IX_user_roles_RoleId", "user_roles", "RoleId");
        migrationBuilder.CreateIndex("IX_users_CompanyId", "users", "CompanyId");
        migrationBuilder.CreateIndex("IX_users_Email", "users", "Email", unique: true);
    }

    /// <inheritdoc />
    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropTable("audit_logs");
        migrationBuilder.DropTable("plants");
        migrationBuilder.DropTable("role_permissions");
        migrationBuilder.DropTable("user_roles");
        migrationBuilder.DropTable("permissions");
        migrationBuilder.DropTable("roles");
        migrationBuilder.DropTable("users");
        migrationBuilder.DropTable("companies");
    }
}
