using Inventrack.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace Inventrack.Infrastructure.Persistence;

/// <summary>Stable identifiers and values used by the initial system seed.</summary>
public static class SeedData
{
    /// <summary>Gets the UTC timestamp assigned to baseline records.</summary>
    public static readonly DateTimeOffset SeededAtUtc = new(2026, 1, 1, 0, 0, 0, TimeSpan.Zero);

    /// <summary>Gets the Administrator role identifier.</summary>
    public static readonly Guid AdministratorRoleId = new("3cb3323d-2485-4ccf-9de9-6b76c7629ea0");

    /// <summary>Gets the system administration permission identifier.</summary>
    public static readonly Guid SystemManagePermissionId = new("91fc5e70-5f0b-487c-b285-1a5489e4ffab");

    /// <summary>Gets the company management permission identifier.</summary>
    public static readonly Guid CompanyManagePermissionId = new("e6a5957c-cfbf-443c-996e-9c032a68c0d4");

    /// <summary>Registers the minimum authorization records required by a new installation.</summary>
    public static void SeedBaselineAuthorization(this ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Role>().HasData(new Role
        {
            Id = AdministratorRoleId,
            Name = "Administrator",
            Description = "Full access to Inventrack.",
            CreatedAtUtc = SeededAtUtc,
        });

        modelBuilder.Entity<Permission>().HasData(
            new Permission
            {
                Id = SystemManagePermissionId,
                Key = "system.manage",
                Description = "Manage system settings and access control.",
                CreatedAtUtc = SeededAtUtc,
            },
            new Permission
            {
                Id = CompanyManagePermissionId,
                Key = "company.manage",
                Description = "Create and manage companies and plants.",
                CreatedAtUtc = SeededAtUtc,
            });

        modelBuilder.Entity<RolePermission>().HasData(
            new RolePermission { RoleId = AdministratorRoleId, PermissionId = SystemManagePermissionId },
            new RolePermission { RoleId = AdministratorRoleId, PermissionId = CompanyManagePermissionId });
    }
}
