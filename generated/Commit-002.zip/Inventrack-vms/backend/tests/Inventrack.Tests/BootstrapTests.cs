namespace Inventrack.Tests;

/// <summary>Verifies that the bootstrap test project is discovered.</summary>
public sealed class BootstrapTests
{
    /// <summary>Confirms the test project is discoverable and executable.</summary>
    [Fact]
    public void Bootstrap_is_available()
    {
        true.Should().BeTrue();
    }
}
