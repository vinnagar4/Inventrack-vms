# Architecture

Inventrack is organised around Clean Architecture boundaries:

- **Domain** holds business concepts and rules, without framework dependencies.
- **Application** will contain use cases and contracts.
- **Infrastructure** will implement data access and external services.
- **API** is the HTTP composition root.
- **Shared** is limited to cross-cutting, dependency-free helpers.

Dependencies point inward: API and Infrastructure may depend on Application; Application may depend on Domain and Shared; Domain remains independent.
