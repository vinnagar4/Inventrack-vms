# Coding standards

- Keep business rules in the Domain or Application layer, never controllers.
- Make dependencies explicit through constructors and interfaces.
- Prefer small, focused types and unit tests alongside new behavior.
- Treat warnings as errors in backend projects.
- Do not commit credentials; use environment-specific configuration outside source control.
