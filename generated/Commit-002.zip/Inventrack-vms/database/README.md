# Database setup

Inventrack uses PostgreSQL with Entity Framework Core migrations.

For local development, the API reads the PostgreSQL connection from `backend/src/Inventrack.Api/appsettings.Development.json`. Do not use that development credential outside a local machine. In other environments set `ConnectionStrings__InventrackDatabase` or supply a production configuration file outside version control.

## Apply the initial schema

```bash
cd backend
dotnet ef database update --project src/Inventrack.Infrastructure --startup-project src/Inventrack.Api
```

The initial migration creates tenant companies, plants, application users, roles, permissions, user-role assignments, role-permission assignments, and audit logs. It seeds the `Administrator` role with `system.manage` and `company.manage` permissions. It deliberately does not seed a login account; Commit 3 introduces secure credential creation and authentication.
