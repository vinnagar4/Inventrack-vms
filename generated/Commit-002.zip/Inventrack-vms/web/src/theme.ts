import { createTheme } from '@mui/material/styles'

export const theme = createTheme({
  palette: { primary: { main: '#0f766e' }, secondary: { main: '#ea580c' } },
  shape: { borderRadius: 8 },
})
