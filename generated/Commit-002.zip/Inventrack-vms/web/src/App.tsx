import { AppBar, Box, Container, Toolbar, Typography } from '@mui/material'
import { Route, Routes } from 'react-router-dom'
import { api } from './lib/api'

function HomePage() {
  void api
  return (
    <Container sx={{ py: 6 }}>
      <Typography variant="h4" gutterBottom>Inventrack VMS</Typography>
      <Typography color="text.secondary">The web workspace is ready for inventory workflows.</Typography>
    </Container>
  )
}

export function App() {
  return (
    <Box>
      <AppBar position="static"><Toolbar><Typography variant="h6">Inventrack</Typography></Toolbar></AppBar>
      <Routes><Route path="*" element={<HomePage />} /></Routes>
    </Box>
  )
}
