# Inventrack VMS

Inventrack is a vendor and inventory management system. The solution establishes the delivery pipeline, web client and Android client shells, then adds PostgreSQL persistence for foundational tenancy and authorization records.

## Structure

| Path | Purpose |
| --- | --- |
| `backend/` | ASP.NET Core 9 API and Clean Architecture projects |
| `web/` | React, TypeScript, Vite and Material UI client |
| `mobile/` | Kotlin and Jetpack Compose Android client |
| `database/` | Reserved migrations and seed-data locations |
| `docs/` | Architecture and engineering standards |

## Run locally

Prerequisites: .NET SDK 9, Node.js 22+ with npm, and Android Studio/JDK 17 for the mobile client.

```bash
cd backend
dotnet restore Inventrack.sln
dotnet run --project src/Inventrack.Api
```

The API exposes `GET /health`, `GET /api/status`, and Swagger in Development at `/swagger`.

Apply the local PostgreSQL schema using the instructions in [`database/README.md`](database/README.md).

```bash
cd web
npm install
npm run dev
```

Open `mobile/` in Android Studio and use its bundled Gradle configuration to run the Android client.

## Verification

```bash
cd backend
dotnet test Inventrack.sln
```

## Commit message

`feat(bootstrap): initialize Inventrack VMS solution using Clean Architecture`

## Next

Commit 3 will introduce JWT authentication, refresh tokens, and role-based access enforcement.
